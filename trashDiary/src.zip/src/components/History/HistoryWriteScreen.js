import React, {useState, useRef, useEffect} from 'react';
import { Alert } from 'react-native';

// Library
import styled from 'styled-components/native';
import { Actions } from 'react-native-router-flux'
import { useRecoilState } from 'recoil'
import { historyState } from "../../atom";
import moment from 'moment-timezone';
import { Textarea, Form, Input, Item } from "native-base";

// Component
import { PageTitle } from '../Common';

const HistoryWrite = () => {

  const [hisotry, setHistory] = useRecoilState(historyState);
  const [content, setContent] = useState(null);
  const [title, setTitle] = useState(null);

  const submit = () => {
    const olds = [...hisotry];
    const newHistory = {
      title,
      content,
      date: Date.now(),
    };

    setHistory([newHistory, ...olds])
    Actions.pop();
  }

  return (
    <>
      <Container>
        <Form>
          <Item regular>
            <Input 
              placeholder='제목을 입력해주세요'
              onChangeText={text => setTitle(text)}  
            />
          </Item>
          <Textarea 
            rowSpan={5} 
            bordered 
            placeholder="오늘의 분리수거 기록을 작성해주세요" 
            onChangeText={text => setContent(text)}  
          />
        </Form>
        <SubmitButton onPress={submit}>
          <SubmitText>
            작성하기
          </SubmitText>
        </SubmitButton>
      </Container>
    </>
  )
}

const Container = styled.View`
  flex: 1;
  background-color: #fff;
  padding: 16px 28px;
`;

const SubmitButton = styled.TouchableOpacity`
  background-color: #b4d39e;
  margin-top: 12px;
  align-items: center;
  padding: 12px 0;
  border-radius: 8px;
`;

const SubmitText = styled.Text`
  color: #fff;
  font-weight: 700;
  font-size: 16px;
`;

export default HistoryWrite;